class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function GenerateApp() {
  try {
    const [rule, setRule] = React.useState(null);
    const [language, setLanguage] = React.useState('Python');
    const [generatedCode, setGeneratedCode] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [showToast, setShowToast] = React.useState(false);
    const [toastMessage, setToastMessage] = React.useState('');

    React.useEffect(() => {
      loadRule();
    }, []);

    const loadRule = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const ruleId = urlParams.get('ruleId');
      if (ruleId) {
        const ruleData = await TrickleDB.getRule(ruleId);
        setRule(ruleData);
      }
    };

    const generateCode = async () => {
      setLoading(true);
      setGeneratedCode('');
      try {
        const code = await TrickleDB.generateCode(rule, language);
        if (code && code.length > 0) {
          setGeneratedCode(code);
          setToastMessage('Code generated successfully!');
          setShowToast(true);
        } else {
          setGeneratedCode('// Using template code due to generation issues\n\n' + 
            TrickleDB.generateFallbackCode(rule, language));
          setToastMessage('Generated template code (AI agent unavailable)');
          setShowToast(true);
        }
      } catch (error) {
        console.error('Code generation error:', error);
        const fallbackCode = TrickleDB.generateFallbackCode(rule, language);
        setGeneratedCode('// Using template code due to errors\n\n' + fallbackCode);
        setToastMessage('Generated template code (network issue detected)');
        setShowToast(true);
      }
      setLoading(false);
    };

    if (!rule) {
      return (
        <div className="min-h-screen">
          <Header />
          <div className="max-w-7xl mx-auto px-4 py-8 text-center">
            <p>Loading rule...</p>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-8">Generate Code</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card">
              <h2 className="text-xl font-bold mb-4">Rule Details</h2>
              <div className="space-y-3">
                <div><span className="font-medium">Rule ID:</span> {rule.ruleId}</div>
                <div><span className="font-medium">Category:</span> {rule.category}</div>
                <div><span className="font-medium">Type:</span> {rule.type}</div>
                <div className="pt-2"><p className="text-lg">{rule.ruleText}</p></div>
              </div>
              
              <div className="mt-6">
                <label className="block font-medium mb-2">Target Language</label>
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg"
                >
                  <option>Python</option>
                  <option>Java</option>
                  <option>Drools</option>
                </select>
              </div>
              
              <button 
                onClick={generateCode}
                disabled={loading}
                className="btn btn-primary w-full mt-4"
              >
                {loading ? 'Generating...' : 'Generate Code'}
              </button>
            </div>

            <div className="card">
              <h2 className="text-xl font-bold mb-4">Generated Code</h2>
              <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-auto max-h-96">
                <code>{generatedCode || '// Click "Generate Code" to see output'}</code>
              </pre>
              {generatedCode && (
                <button 
                  onClick={() => window.location.href = 'repository.html'}
                  className="btn btn-primary w-full mt-4"
                >
                  Commit to Repository
                </button>
              )}
            </div>
          </div>
        </main>
        {showToast && <Toast message={toastMessage} onClose={() => setShowToast(false)} />}
      </div>
    );
  } catch (error) {
    console.error('GenerateApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><GenerateApp /></ErrorBoundary>);