# Policy Codification Platform

## Overview
AI-powered platform that converts organizational policy documents into executable code with intelligent rule extraction, review workflows, and version control.

## Key Features
- **Document Upload**: PDF, Word, Excel support with drag-and-drop
- **AI Rule Extraction**: LLM-powered extraction of actions, obligations, and controls
- **Review Workflow**: Approve/Reject/Edit rules with explainability
- **Code Generation**: Generate Java, Python, or Drools code
- **Code Comparison**: Side-by-side diff viewer with color coding
- **Semantic Search**: Find rules using natural language
- **Audit Trail**: Complete action logging and history
- **Local Repository**: Git-based version control

## Tech Stack
- Frontend: React 18 + Tailwind CSS
- Database: Supabase (PostgreSQL)
- AI: OpenAI GPT-4/GPT-5 via invokeAIAgent
- Version Control: Local Git repository

## Pages
- `/` - Dashboard with upload and workflow
- `review.html` - Rule review and approval
- `generate.html` - Code generation and comparison
- `search.html` - Semantic rule search
- `audit.html` - Audit trail viewer
- `repository.html` - Version history

## Database Tables
- documents: Uploaded policy files
- rules: Extracted and approved rules
- versions: Git commit history
- audit_logs: All user actions
- embeddings: Semantic search vectors

## Current Status
✅ Dashboard and upload interface
⏳ Rule extraction and review (next)
⏳ Code generation
⏳ Semantic search
⏳ Repository management