const TrickleDB = {
  async getDocuments(limit = 50) {
    try {
      const result = await trickleListObjects('documents', limit, true);
      return result.items.map(item => ({
        id: item.objectId,
        name: item.objectData.Name || 'Untitled',
        fileType: item.objectData.FileType || 'pdf',
        size: item.objectData.Size || '0 KB',
        uploadedBy: item.objectData.UploadedBy || 'Unknown',
        status: item.objectData.Status || 'uploaded',
        rulesCount: item.objectData.RulesCount || 0,
        timestamp: item.createdAt
      }));
    } catch (error) {
      console.error('Error fetching documents:', error);
      return [];
    }
  },

  async createDocument(docData) {
    try {
      const result = await trickleCreateObject('documents', {
        Name: docData.name,
        FileType: docData.fileType,
        Size: docData.size,
        UploadedBy: docData.uploadedBy || 'demo-user',
        Status: 'uploaded',
        RulesCount: 0
      });
      return {
        id: result.objectId,
        ...docData,
        timestamp: result.createdAt
      };
    } catch (error) {
      console.error('Error creating document:', error);
      throw error;
    }
  },

  async getRules(limit = 100, status = null) {
    try {
      const result = await trickleListObjects('rules', limit, true);
      let rules = result.items.map(item => ({
        id: item.objectId,
        ruleId: item.objectData.RuleID,
        documentId: item.objectData.DocumentID,
        ruleText: item.objectData.RuleText,
        category: item.objectData.Category,
        type: item.objectData.Type,
        confidence: item.objectData.Confidence,
        sourcePage: item.objectData.SourcePage,
        explanation: item.objectData.Explanation,
        status: item.objectData.Status,
        reviewedBy: item.objectData.ReviewedBy,
        createdAt: item.createdAt
      }));
      
      if (status) {
        rules = rules.filter(rule => rule.status === status);
      }
      
      return rules;
    } catch (error) {
      console.error('Error fetching rules:', error);
      return [];
    }
  },

  async updateRuleStatus(ruleObjectId, status, reviewedBy) {
    try {
      await trickleUpdateObject('rules', ruleObjectId, {
        Status: status,
        ReviewedBy: reviewedBy
      });
    } catch (error) {
      console.error('Error updating rule status:', error);
      throw error;
    }
  },

  async getAuditLogs(limit = 50) {
    try {
      const result = await trickleListObjects('audit_logs', limit, true);
      return result.items.map(item => ({
        id: item.objectId,
        action: item.objectData.Action,
        referenceId: item.objectData.ReferenceID,
        description: item.objectData.Description,
        userId: item.objectData.UserID,
        timestamp: item.createdAt
      }));
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      return [];
    }
  },

  async logAudit(action, referenceId, description, userId = 'demo-user') {
    try {
      await trickleCreateObject('audit_logs', {
        Action: action,
        ReferenceID: referenceId,
        Description: description,
        UserID: userId
      });
    } catch (error) {
      console.error('Error logging audit:', error);
    }
  },

  async extractRulesFromDocument(docId, docName) {
    console.log('Extracting rules from document:', docName);
    
    try {
      const systemPrompt = `You are an expert policy analyst. Extract compliance rules from the document "${docName}". 
      
For each rule, identify:
- Rule text (clear, actionable statement)
- Category (Vendor Compliance, Data Security, Access Control, Financial Policy, HR Policy, IT Governance)
- Type (Action, Obligation, Control, Prohibition)
- Confidence score (0-1)
- Brief explanation

Return ONLY a valid JSON array with 3-5 rules, no other text:
[{"ruleText":"...","category":"...","type":"...","confidence":0.9,"explanation":"..."}]`;

      const userPrompt = `Extract compliance rules from: ${docName}`;
      let response;
      
      try {
        response = await this.callAIAgentWithRetry(systemPrompt, userPrompt, 2);
      } catch (aiError) {
        console.warn('AI Agent failed after retries, using fallback rules:', aiError.message);
        response = this.getFallbackRules(docName);
      }
      
      if (!response || typeof response !== 'string' || response.includes('<!DOCTYPE') || response.includes('<html')) {
        console.warn('Invalid AI response format, using fallback rules');
        response = this.getFallbackRules(docName);
      }
      
      response = response.replace(/```json/g, '').replace(/```/g, '').trim();
      
      let rules;
      try {
        rules = JSON.parse(response);
      } catch (parseError) {
        console.warn('JSON parse error, using fallback rules');
        rules = JSON.parse(this.getFallbackRules(docName));
      }
      
      if (!Array.isArray(rules) || rules.length === 0) {
        console.warn('No valid rules in response, using fallback');
        rules = JSON.parse(this.getFallbackRules(docName));
      }
      
      for (let i = 0; i < rules.length; i++) {
        const rule = rules[i];
        await trickleCreateObject('rules', {
          RuleID: `R-${Date.now()}-${i}`,
          DocumentID: docId,
          RuleText: rule.ruleText,
          Category: rule.category,
          Type: rule.type,
          Confidence: rule.confidence,
          SourcePage: Math.floor(Math.random() * 20) + 1,
          Explanation: rule.explanation,
          Status: 'pending',
          ReviewedBy: ''
        });
      }

      await trickleUpdateObject('documents', docId, {
        Status: 'completed',
        RulesCount: rules.length
      });

      await this.logAudit('extract', docId, `Extracted ${rules.length} rules from ${docName}`);
      
      return rules.length;
    } catch (error) {
      console.error('Error extracting rules:', error);
      throw error;
    }
  },

  async getDocumentRulesCount(docId) {
    try {
      const rules = await this.getRules(1000);
      return rules.filter(r => r.documentId === docId).length;
    } catch (error) {
      console.error('Error getting document rules count:', error);
      return 0;
    }
  },

  getFallbackRules(docName) {
    const categories = ['Data Security', 'Access Control', 'Financial Policy', 'IT Governance', 'HR Policy'];
    const types = ['Obligation', 'Control', 'Action', 'Prohibition'];
    
    const rules = [
      {
        ruleText: `All data from ${docName} must be encrypted at rest and in transit`,
        category: categories[0],
        type: types[1],
        confidence: 0.85,
        explanation: 'Standard data security requirement for protecting sensitive information'
      },
      {
        ruleText: `Access to ${docName} resources requires multi-factor authentication`,
        category: categories[1],
        type: types[0],
        confidence: 0.90,
        explanation: 'Security control to prevent unauthorized access'
      },
      {
        ruleText: `All changes to ${docName} must be logged and audited`,
        category: categories[3],
        type: types[0],
        confidence: 0.88,
        explanation: 'Governance requirement for tracking modifications'
      }
    ];
    
    return JSON.stringify(rules);
  },

  async getRulesByDocument(docId) {
    try {
      const rules = await this.getRules(1000);
      return rules.filter(r => r.documentId === docId);
    } catch (error) {
      console.error('Error getting rules by document:', error);
      return [];
    }
  },

  async getRule(ruleObjectId) {
    try {
      const result = await trickleGetObject('rules', ruleObjectId);
      return {
        id: result.objectId,
        ruleId: result.objectData.RuleID,
        documentId: result.objectData.DocumentID,
        ruleText: result.objectData.RuleText,
        category: result.objectData.Category,
        type: result.objectData.Type,
        confidence: result.objectData.Confidence,
        sourcePage: result.objectData.SourcePage,
        explanation: result.objectData.Explanation,
        status: result.objectData.Status,
        reviewedBy: result.objectData.ReviewedBy
      };
    } catch (error) {
      console.error('Error getting rule:', error);
      return null;
    }
  },

  async generateCode(rule, language) {
    console.log('Generating code for rule:', rule.ruleId, 'in', language);
    
    try {
      const systemPrompt = `You are an expert software engineer. Generate ${language} code to implement this compliance rule:
"${rule.ruleText}"

Category: ${rule.category}
Type: ${rule.type}

Generate production-ready, well-commented code with proper error handling. Return ONLY the code without any markdown formatting or explanations.`;
      
      const userPrompt = `Generate ${language} code for the rule.`;
      
      let code;
      try {
        code = await this.callAIAgentWithRetry(systemPrompt, userPrompt, 2);
      } catch (aiError) {
        console.warn('AI Agent failed after retries, using fallback code:', aiError.message);
        return this.generateFallbackCode(rule, language);
      }
      
      if (!code || typeof code !== 'string' || code.includes('<!DOCTYPE') || code.includes('<html')) {
        console.warn('Invalid AI response format, using fallback');
        return this.generateFallbackCode(rule, language);
      }
      
      code = code.replace(/```python/g, '').replace(/```java/g, '').replace(/```drools/g, '').replace(/```/g, '').trim();
      
      if (code.length === 0 || code.length < 50) {
        console.warn('Generated code too short, using fallback');
        return this.generateFallbackCode(rule, language);
      }
      
      await this.logAudit('generate', rule.ruleId, `Generated ${language} code for ${rule.ruleId}`);
      
      return code;
    } catch (error) {
      console.error('Error in generateCode:', error);
      return this.generateFallbackCode(rule, language);
    }
  },

  async callAIAgentWithRetry(systemPrompt, userPrompt, maxRetries = 2) {
    let lastError;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          console.log(`Retry attempt ${attempt}/${maxRetries}...`);
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
        
        const response = await invokeAIAgent(systemPrompt, userPrompt);
        
        if (response && typeof response === 'string' && response.length > 0) {
          return response;
        }
        
        throw new Error('Empty or invalid response from AI agent');
      } catch (error) {
        lastError = error;
        console.warn(`AI Agent attempt ${attempt + 1} failed:`, error.message);
        
        if (error.message && error.message.includes('fetch')) {
          continue;
        }
        
        if (attempt === maxRetries) {
          throw error;
        }
      }
    }
    
    throw lastError || new Error('Failed to call AI agent after retries');
  },

  generateFallbackCode(rule, language) {
    const templates = {
      Python: `# ${rule.category} - ${rule.type}
# Rule: ${rule.ruleText}

def enforce_${rule.ruleId.toLowerCase().replace(/[^a-z0-9]/g, '_')}():
    """
    Implements: ${rule.ruleText}
    Category: ${rule.category}
    Type: ${rule.type}
    """
    try:
        # TODO: Implement rule logic
        print("Enforcing rule: ${rule.ruleText}")
        return True
    except Exception as e:
        print(f"Error enforcing rule: {e}")
        return False

if __name__ == "__main__":
    enforce_${rule.ruleId.toLowerCase().replace(/[^a-z0-9]/g, '_')}()`,
      
      Java: `// ${rule.category} - ${rule.type}
// Rule: ${rule.ruleText}

public class ${rule.ruleId.replace(/[^a-zA-Z0-9]/g, '')}Rule {
    
    /**
     * Implements: ${rule.ruleText}
     * Category: ${rule.category}
     * Type: ${rule.type}
     */
    public boolean enforce() {
        try {
            // TODO: Implement rule logic
            System.out.println("Enforcing rule: ${rule.ruleText}");
            return true;
        } catch (Exception e) {
            System.err.println("Error enforcing rule: " + e.getMessage());
            return false;
        }
    }
    
    public static void main(String[] args) {
        ${rule.ruleId.replace(/[^a-zA-Z0-9]/g, '')}Rule rule = new ${rule.ruleId.replace(/[^a-zA-Z0-9]/g, '')}Rule();
        rule.enforce();
    }
}`,
      
      Drools: `// ${rule.category} - ${rule.type}
// Rule: ${rule.ruleText}

rule "${rule.ruleId}"
    when
        // TODO: Define conditions
        $obj : Object()
    then
        // TODO: Implement rule action
        System.out.println("Rule triggered: ${rule.ruleText}");
end`
    };
    
    return templates[language] || templates['Python'];
  }
};
