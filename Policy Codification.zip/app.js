class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const [documents, setDocuments] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [showToast, setShowToast] = React.useState(false);
    const [toastMessage, setToastMessage] = React.useState('');
    const [toastType, setToastType] = React.useState('success');

    React.useEffect(() => {
      loadDocuments();
    }, []);

    const loadDocuments = async () => {
      try {
        setLoading(true);
        const docs = await TrickleDB.getDocuments();
        setDocuments(docs);
      } catch (error) {
        showNotification('Failed to load documents', 'error');
      } finally {
        setLoading(false);
      }
    };

    const showNotification = (message, type = 'success') => {
      setToastMessage(message);
      setToastType(type);
      setShowToast(true);
    };

    const handleUploadComplete = async (docData) => {
      setDocuments([docData, ...documents]);
      showNotification('Document uploaded successfully!');
      await TrickleDB.logAudit('upload', docData.id, `Uploaded ${docData.name}`);
    };

    return (
      <div className="min-h-screen" data-name="app" data-file="app.js">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Policy Codification Platform</h1>
            <p className="text-[var(--text-secondary)] text-lg">
              Transform policy documents into executable code with AI-powered rule extraction
            </p>
          </div>
          
          <WorkflowSteps currentStep={0} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <FileUpload onUploadComplete={handleUploadComplete} showNotification={showNotification} />
            <RecentDocuments documents={documents} loading={loading} />
          </div>
        </main>
        {showToast && <Toast message={toastMessage} type={toastType} onClose={() => setShowToast(false)} />}
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);