class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function GenerateApp() {
  try {
    const [rule, setRule] = React.useState(null);
    const [language, setLanguage] = React.useState('Python');
    const [generatedCode, setGeneratedCode] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [showToast, setShowToast] = React.useState(false);
    const [toastMessage, setToastMessage] = React.useState('');

    React.useEffect(() => {
      loadRule();
    }, []);

    const loadRule = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const ruleId = urlParams.get('ruleId');
      if (ruleId) {
        const ruleData = await TrickleDB.getRule(ruleId);
        setRule(ruleData);
      }
    };

    const generateCode = async () => {
      if (!rule) {
        setToastMessage('No rule selected');
        setShowToast(true);
        return;
      }
      
      setLoading(true);
      setGeneratedCode('');
      
      const code = TrickleDB.generateCode(rule, language);
      setGeneratedCode(code);
      setToastMessage('Code generated successfully!');
      setShowToast(true);
      await TrickleDB.logAudit('generate', rule.ruleId, `Generated ${language} code`);
      
      setLoading(false);
    };

    if (!rule) {
      return (
        <div className="min-h-screen">
          <Header />
          <div className="max-w-7xl mx-auto px-4 py-8 text-center">
            <p>Loading rule...</p>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-8">Generate Code</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="card">
              <h2 className="text-xl font-bold mb-4">Rule Details</h2>
              <div className="space-y-3">
                <div><span className="font-medium">Rule ID:</span> {rule.ruleId}</div>
                <div><span className="font-medium">Category:</span> {rule.category}</div>
                <div><span className="font-medium">Type:</span> {rule.type}</div>
                <div className="pt-2"><p className="text-lg">{rule.ruleText}</p></div>
              </div>
              
              <div className="mt-6">
                <label className="block font-medium mb-2">Target Language</label>
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg"
                >
                  <option>Python</option>
                  <option>Java</option>
                  <option>Drools</option>
                </select>
              </div>
              
              <button 
                onClick={generateCode}
                disabled={loading}
                className="btn btn-primary w-full mt-4"
              >
                {loading ? 'Generating...' : 'Generate Code'}
              </button>
            </div>

            <div className="card">
              <h2 className="text-xl font-bold mb-4">Generated Code</h2>
              {loading ? (
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg min-h-96 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full border-4 border-gray-700 border-t-green-400 animate-spin mx-auto mb-4"></div>
                    <p>Generating {language} code...</p>
                  </div>
                </div>
              ) : (
                <>
                  <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-auto max-h-96 font-mono text-sm">
                    <code>{generatedCode || '// Click "Generate Code" to see output'}</code>
                  </pre>
                  {generatedCode && (
                    <div className="flex space-x-3 mt-4">
                      <button 
                        onClick={() => {
                          navigator.clipboard.writeText(generatedCode);
                          setToastMessage('Code copied to clipboard!');
                          setShowToast(true);
                        }}
                        className="btn btn-secondary flex-1 flex items-center justify-center space-x-2"
                      >
                        <div className="icon-copy text-lg"></div>
                        <span>Copy Code</span>
                      </button>
                      <button 
                        onClick={() => window.location.href = 'repository.html'}
                        className="btn btn-primary flex-1 flex items-center justify-center space-x-2"
                      >
                        <div className="icon-git-commit text-lg"></div>
                        <span>Commit to Repository</span>
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </main>
        {showToast && <Toast message={toastMessage} onClose={() => setShowToast(false)} />}
      </div>
    );
  } catch (error) {
    console.error('GenerateApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><GenerateApp /></ErrorBoundary>);