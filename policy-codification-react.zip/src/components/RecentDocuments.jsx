function RecentDocuments({ documents, loading }) {
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">Recent Documents</h2>
      {loading ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 rounded-full border-4 border-gray-200 border-t-[var(--primary-color)] animate-spin mx-auto mb-4"></div>
          <p className="text-[var(--text-secondary)]">Loading...</p>
        </div>
      ) : documents.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
            <div className="icon-file-text text-2xl text-gray-400"></div>
          </div>
          <p className="text-[var(--text-secondary)]">No documents yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {documents.map((doc) => (
            <div 
              key={doc.id} 
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <div className="icon-file-text text-lg text-[var(--primary-color)]"></div>
                </div>
                <div>
                  <p className="font-medium">{doc.name}</p>
                  <p className="text-sm text-[var(--text-secondary)]">
                    {doc.size} • {new Date(doc.timestamp).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                  {doc.rulesCount} rules
                </span>
                <button onClick={() => window.location.href = `review.html?docId=${doc.id}`}>
                  <div className="icon-chevron-right text-lg text-[var(--text-secondary)]"></div>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}