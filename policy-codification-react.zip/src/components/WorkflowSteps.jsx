function WorkflowSteps({ currentStep = 0 }) {
  const steps = [
    { label: 'Upload', icon: 'upload' },
    { label: 'Extract', icon: 'file-text' },
    { label: 'Review', icon: 'list-checks' },
    { label: 'Generate', icon: 'code' },
    { label: 'Compare', icon: 'git-compare' },
    { label: 'Commit', icon: 'git-commit' }
  ];

  return (
    <div className="card">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <React.Fragment key={index}>
            <div className="flex flex-col items-center">
              <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${
                index <= currentStep 
                  ? 'bg-[var(--primary-color)] text-white' 
                  : 'bg-gray-200 text-gray-400'
              }`}>
                <div className={`icon-${step.icon} text-xl`}></div>
              </div>
              <span className={`text-sm font-medium ${
                index <= currentStep 
                  ? 'text-[var(--text-primary)]' 
                  : 'text-[var(--text-secondary)]'
              }`}>
                {step.label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={`flex-1 h-1 mx-2 rounded ${
                index < currentStep ? 'bg-[var(--primary-color)]' : 'bg-gray-200'
              }`}></div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}