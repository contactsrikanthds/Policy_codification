function FileUpload({ onUploadComplete, showNotification }) {
  const { useState, useRef } = React;
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef(null);

  const handleFiles = async (files) => {
    const validFiles = files.filter(f => 
      f.type === 'application/pdf' || 
      f.name.endsWith('.docx') || 
      f.name.endsWith('.xlsx')
    );

    if (validFiles.length === 0) {
      showNotification('Please upload PDF, Word, or Excel files', 'error');
      return;
    }

    setUploading(true);
    setProgress(0);

    for (let i = 0; i < validFiles.length; i++) {
      const file = validFiles[i];
      setProgress(((i + 1) / validFiles.length) * 100);
      
      try {
        const docData = await TrickleDB.createDocument({
          name: file.name,
          fileType: file.name.split('.').pop(),
          size: (file.size / 1024).toFixed(2) + ' KB',
          uploadedBy: 'demo-user'
        });
        
        showNotification(`Extracting rules from ${file.name}...`, 'info');
        await TrickleDB.extractRulesFromDocument(docData.id, file.name);
        docData.rulesCount = await TrickleDB.getDocumentRulesCount(docData.id);
        showNotification(`Extracted ${docData.rulesCount} rules!`);
        onUploadComplete(docData);
      } catch (error) {
        showNotification(`Failed to upload ${file.name}`, 'error');
      }
    }

    setUploading(false);
    setProgress(0);
  };

  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-4">Upload Policy Documents</h2>
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => { 
          e.preventDefault(); 
          setIsDragging(false); 
          handleFiles(Array.from(e.dataTransfer.files)); 
        }}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer ${
          isDragging ? 'border-[var(--primary-color)] bg-blue-50' : 'border-[var(--border-color)]'
        }`}
      >
        <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
          <div className="icon-upload text-2xl text-[var(--primary-color)]"></div>
        </div>
        <p className="text-lg font-medium mb-2">Drop files or click to browse</p>
        <p className="text-sm text-[var(--text-secondary)]">PDF, Word, Excel supported</p>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".pdf,.docx,.xlsx"
          onChange={(e) => handleFiles(Array.from(e.target.files))}
          className="hidden"
        />
      </div>
      {uploading && (
        <div className="mt-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium">Uploading...</span>
            <span className="text-sm">{progress.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-[var(--primary-color)] h-2 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      )}
    </div>
  );
}