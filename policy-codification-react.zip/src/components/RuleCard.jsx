function RuleCard({ rule, onApprove, onReject }) {
  try {
    const statusColors = {
      pending: 'bg-yellow-100 text-yellow-700',
      approved: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
      modified: 'bg-blue-100 text-blue-700'
    };

    const typeIcons = {
      Action: 'zap',
      Obligation: 'alert-circle',
      Control: 'shield',
      Prohibition: 'x-circle'
    };

    return (
      <div className="card" data-name="rule-card" data-file="components/RuleCard.jsx">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <div className={`icon-${typeIcons[rule.type] || 'file-text'} text-lg text-[var(--primary-color)]`}></div>
            </div>
            <div>
              <span className="font-bold text-lg">{rule.ruleId}</span>
              <div className="flex items-center space-x-2 mt-1">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[rule.status]}`}>
                  {rule.status.toUpperCase()}
                </span>
                <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                  {rule.category}
                </span>
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                  {rule.type}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="icon-cpu text-lg text-[var(--text-secondary)]"></div>
            <span className="text-sm font-medium">{(rule.confidence * 100).toFixed(0)}%</span>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-lg mb-2">{rule.ruleText}</p>
          <div className="flex items-center space-x-4 text-sm text-[var(--text-secondary)]">
            <span className="flex items-center space-x-1">
              <div className="icon-file-text text-base"></div>
              <span>Page {rule.sourcePage}</span>
            </span>
            {rule.reviewedBy && (
              <span className="flex items-center space-x-1">
                <div className="icon-user text-base"></div>
                <span>{rule.reviewedBy}</span>
              </span>
            )}
          </div>
        </div>

        <div className="bg-blue-50 rounded-lg p-4 mb-4">
          <div className="flex items-start space-x-2">
            <div className="icon-lightbulb text-lg text-[var(--primary-color)] mt-0.5"></div>
            <div>
              <p className="text-sm font-medium mb-1">AI Explanation</p>
              <p className="text-sm text-[var(--text-secondary)]">{rule.explanation}</p>
            </div>
          </div>
        </div>

        {rule.status === 'pending' && (
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => onApprove(rule)}
              className="btn btn-success flex items-center space-x-2 flex-1"
            >
              <div className="icon-check text-lg"></div>
              <span>Approve</span>
            </button>
            <button 
              onClick={() => onReject(rule)}
              className="btn btn-danger flex items-center space-x-2 flex-1"
            >
              <div className="icon-x text-lg"></div>
              <span>Reject</span>
            </button>
          </div>
        )}
        {rule.status === 'approved' && (
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => window.location.href = `generate.html?ruleId=${rule.id}`}
              className="btn btn-primary flex items-center space-x-2 flex-1"
            >
              <div className="icon-code text-lg"></div>
              <span>Generate Code</span>
            </button>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('RuleCard component error:', error);
    return null;
  }
}