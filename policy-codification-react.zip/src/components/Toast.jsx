function Toast({ message, type = 'success', onClose }) {
  React.useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const icons = {
    success: 'check-circle',
    error: 'x-circle',
    warning: 'alert-circle',
    info: 'info'
  };

  const colors = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    warning: 'bg-yellow-500',
    info: 'bg-blue-500'
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className={`${colors[type]} text-white px-6 py-4 rounded-lg shadow-lg flex items-center space-x-3 min-w-[300px]`}>
        <div className={`icon-${icons[type]} text-xl`}></div>
        <span className="font-medium">{message}</span>
        <button onClick={onClose} className="ml-auto">
          <div className="icon-x text-lg"></div>
        </button>
      </div>
    </div>
  );
}