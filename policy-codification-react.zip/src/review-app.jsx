class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button onClick={() => window.location.reload()} className="btn btn-primary">
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ReviewApp() {
  try {
    const [rules, setRules] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [filter, setFilter] = React.useState('all');
    const [showToast, setShowToast] = React.useState(false);
    const [toastMessage, setToastMessage] = React.useState('');
    const [toastType, setToastType] = React.useState('success');

    React.useEffect(() => {
      loadRules();
    }, []);

    const loadRules = async () => {
      try {
        setLoading(true);
        const urlParams = new URLSearchParams(window.location.search);
        const docId = urlParams.get('docId');
        
        let allRules;
        if (docId) {
          allRules = await TrickleDB.getRulesByDocument(docId);
        } else {
          allRules = await TrickleDB.getRules();
        }
        setRules(allRules);
      } catch (error) {
        showNotification('Failed to load rules', 'error');
      } finally {
        setLoading(false);
      }
    };

    const showNotification = (message, type = 'success') => {
      setToastMessage(message);
      setToastType(type);
      setShowToast(true);
    };

    const handleApprove = async (rule) => {
      try {
        await TrickleDB.updateRuleStatus(rule.id, 'approved', 'demo-user');
        await TrickleDB.logAudit('approve', rule.ruleId, `Approved rule: ${rule.ruleText.substring(0, 50)}...`);
        setRules(rules.map(r => r.id === rule.id ? {...r, status: 'approved', reviewedBy: 'demo-user'} : r));
        showNotification('Rule approved successfully');
      } catch (error) {
        showNotification('Failed to approve rule', 'error');
      }
    };

    const handleReject = async (rule) => {
      try {
        await TrickleDB.updateRuleStatus(rule.id, 'rejected', 'demo-user');
        await TrickleDB.logAudit('reject', rule.ruleId, `Rejected rule: ${rule.ruleText.substring(0, 50)}...`);
        setRules(rules.map(r => r.id === rule.id ? {...r, status: 'rejected', reviewedBy: 'demo-user'} : r));
        showNotification('Rule rejected', 'warning');
      } catch (error) {
        showNotification('Failed to reject rule', 'error');
      }
    };

    const filteredRules = filter === 'all' ? rules : rules.filter(r => r.status === filter);

    return (
      <div className="min-h-screen" data-name="review-app" data-file="review-app.jsx">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Review Extracted Rules</h1>
            <p className="text-[var(--text-secondary)] text-lg">
              Approve, reject, or modify AI-extracted policy rules
            </p>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            <button 
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-lg font-medium ${filter === 'all' ? 'bg-[var(--primary-color)] text-white' : 'bg-gray-200 text-gray-700'}`}
            >
              All ({rules.length})
            </button>
            <button 
              onClick={() => setFilter('pending')}
              className={`px-4 py-2 rounded-lg font-medium ${filter === 'pending' ? 'bg-[var(--warning)] text-white' : 'bg-gray-200 text-gray-700'}`}
            >
              Pending ({rules.filter(r => r.status === 'pending').length})
            </button>
            <button 
              onClick={() => setFilter('approved')}
              className={`px-4 py-2 rounded-lg font-medium ${filter === 'approved' ? 'bg-[var(--success)] text-white' : 'bg-gray-200 text-gray-700'}`}
            >
              Approved ({rules.filter(r => r.status === 'approved').length})
            </button>
            <button 
              onClick={() => setFilter('rejected')}
              className={`px-4 py-2 rounded-lg font-medium ${filter === 'rejected' ? 'bg-[var(--danger)] text-white' : 'bg-gray-200 text-gray-700'}`}
            >
              Rejected ({rules.filter(r => r.status === 'rejected').length})
            </button>
          </div>

          {loading ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-full border-4 border-gray-200 border-t-[var(--primary-color)] animate-spin mx-auto mb-4"></div>
              <p className="text-[var(--text-secondary)]">Loading rules...</p>
            </div>
          ) : filteredRules.length === 0 ? (
            <div className="text-center py-12 card">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <div className="icon-list-checks text-2xl text-gray-400"></div>
              </div>
              <p className="text-[var(--text-secondary)]">No rules found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredRules.map(rule => (
                <RuleCard 
                  key={rule.id} 
                  rule={rule} 
                  onApprove={handleApprove}
                  onReject={handleReject}
                />
              ))}
            </div>
          )}
        </main>
        {showToast && <Toast message={toastMessage} type={toastType} onClose={() => setShowToast(false)} />}
      </div>
    );
  } catch (error) {
    console.error('ReviewApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <ReviewApp />
  </ErrorBoundary>
);