When the project structure, features, or functionality is updated

- Update the corresponding content in `trickle/notes/README.md`
- Ensure the README reflects current project status
- Update feature checklist (✅ completed, ⏳ pending)
- Document any new pages, components, or database tables
- Keep tech stack and architecture sections accurate