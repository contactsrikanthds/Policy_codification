# Policy Codification React App\n\nReact project reconstructed with original source structure intact.\n\nRun commands:\n\n```
npm install\nnpm start\n```