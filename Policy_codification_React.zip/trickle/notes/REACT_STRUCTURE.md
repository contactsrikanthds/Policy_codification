# React Application Structure

## Overview
Complete React application with modular component architecture using React 18 and Babel for JSX transformation.

## Component Structure

### Main Components
- **App.js** - Main application component with state management
- **Header.js** - Navigation header used across all pages
- **Toast.js** - Notification component for user feedback
- **WorkflowSteps.js** - Visual workflow progress indicator
- **FileUpload.js** - Drag-and-drop file upload component
- **RecentDocuments.js** - Document list display component
- **RuleCard.js** - Individual rule display and action component

### Utilities
- **TrickleDB.js** - Database abstraction layer for Trickle objects

## Pages
- **index.html** - Dashboard with upload and recent documents
- **review.html** - Rule review and approval interface
- **generate.html** - Code generation from approved rules
- **search.html** - Semantic search for rules
- **audit.html** - Audit trail viewer
- **repository.html** - Git repository and version history

## State Management
Using React Hooks (useState, useEffect, useRef) for component state management.

## Data Flow
1. User uploads document → TrickleDB creates document object
2. AI extracts rules → Rules stored in Trickle database
3. User reviews rules → Status updated (approved/rejected)
4. Generate code → Template code created from rule
5. All actions logged → Audit trail maintained

## Technology Stack
- React 18 with createRoot API
- Babel standalone for JSX transformation
- TailwindCSS for styling
- Lucide icons for UI elements
- Trickle database for data persistence