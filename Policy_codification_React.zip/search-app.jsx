class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function SearchApp() {
  try {
    const [query, setQuery] = React.useState('');
    const [results, setResults] = React.useState([]);
    const [searching, setSearching] = React.useState(false);
    const [allRules, setAllRules] = React.useState([]);

    React.useEffect(() => {
      loadAllRules();
    }, []);

    const loadAllRules = async () => {
      const rules = await TrickleDB.getRules(1000);
      setAllRules(rules);
    };

    const handleSearch = () => {
      if (!query.trim()) return;
      
      setSearching(true);
      
      setTimeout(() => {
        const filtered = allRules.filter(rule => 
          rule.ruleText.toLowerCase().includes(query.toLowerCase()) ||
          rule.category.toLowerCase().includes(query.toLowerCase()) ||
          rule.type.toLowerCase().includes(query.toLowerCase())
        );
        setResults(filtered);
        setSearching(false);
      }, 500);
    };

    return (
      <div className="min-h-screen">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-2">Search Rules</h1>
          <p className="text-[var(--text-secondary)] text-lg mb-8">
            Find policy rules using natural language search
          </p>

          <div className="card mb-8">
            <div className="flex space-x-4">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Search for rules... (e.g., 'data encryption' or 'access control')"
                className="flex-1 px-4 py-3 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
              />
              <button 
                onClick={handleSearch}
                disabled={searching}
                className="btn btn-primary flex items-center space-x-2"
              >
                <div className="icon-search text-lg"></div>
                <span>{searching ? 'Searching...' : 'Search'}</span>
              </button>
            </div>
          </div>

          {searching ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-full border-4 border-gray-200 border-t-[var(--primary-color)] animate-spin mx-auto mb-4"></div>
              <p className="text-[var(--text-secondary)]">Searching rules...</p>
            </div>
          ) : results.length > 0 ? (
            <div>
              <p className="text-[var(--text-secondary)] mb-4">Found {results.length} matching rules</p>
              <div className="space-y-4">
                {results.map(rule => (
                  <RuleCard key={rule.id} rule={rule} onApprove={() => {}} onReject={() => {}} />
                ))}
              </div>
            </div>
          ) : query && !searching ? (
            <div className="text-center py-12 card">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                <div className="icon-search text-2xl text-gray-400"></div>
              </div>
              <p className="text-[var(--text-secondary)]">No rules found for "{query}"</p>
            </div>
          ) : null}
        </main>
      </div>
    );
  } catch (error) {
    console.error('SearchApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><SearchApp /></ErrorBoundary>);
