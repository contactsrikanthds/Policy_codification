const TrickleDB = {
  async getDocuments(limit = 50) {
    try {
      const result = await trickleListObjects('documents', limit, true);
      return result.items.map(item => ({
        id: item.objectId,
        name: item.objectData.Name || 'Untitled',
        fileType: item.objectData.FileType || 'pdf',
        size: item.objectData.Size || '0 KB',
        uploadedBy: item.objectData.UploadedBy || 'Unknown',
        status: item.objectData.Status || 'uploaded',
        rulesCount: item.objectData.RulesCount || 0,
        timestamp: item.createdAt
      }));
    } catch (error) {
      console.error('Error fetching documents:', error);
      return [];
    }
  },

  async createDocument(docData) {
    try {
      const result = await trickleCreateObject('documents', {
        Name: docData.name,
        FileType: docData.fileType,
        Size: docData.size,
        UploadedBy: docData.uploadedBy || 'demo-user',
        Status: 'uploaded',
        RulesCount: 0
      });
      return {
        id: result.objectId,
        ...docData,
        timestamp: result.createdAt
      };
    } catch (error) {
      console.error('Error creating document:', error);
      throw error;
    }
  },

  async getRules(limit = 100, status = null) {
    try {
      const result = await trickleListObjects('rules', limit, true);
      let rules = result.items.map(item => ({
        id: item.objectId,
        ruleId: item.objectData.RuleID,
        documentId: item.objectData.DocumentID,
        ruleText: item.objectData.RuleText,
        category: item.objectData.Category,
        type: item.objectData.Type,
        confidence: item.objectData.Confidence,
        sourcePage: item.objectData.SourcePage,
        explanation: item.objectData.Explanation,
        status: item.objectData.Status,
        reviewedBy: item.objectData.ReviewedBy,
        createdAt: item.createdAt
      }));
      
      if (status) {
        rules = rules.filter(rule => rule.status === status);
      }
      
      return rules;
    } catch (error) {
      console.error('Error fetching rules:', error);
      return [];
    }
  },

  async updateRuleStatus(ruleObjectId, status, reviewedBy) {
    try {
      await trickleUpdateObject('rules', ruleObjectId, {
        Status: status,
        ReviewedBy: reviewedBy
      });
    } catch (error) {
      console.error('Error updating rule:', error);
      throw error;
    }
  },

  async getAuditLogs(limit = 50) {
    try {
      const result = await trickleListObjects('audit_logs', limit, true);
      return result.items.map(item => ({
        id: item.objectId,
        action: item.objectData.Action,
        referenceId: item.objectData.ReferenceID,
        description: item.objectData.Description,
        userId: item.objectData.UserID,
        timestamp: item.createdAt
      }));
    } catch (error) {
      return [];
    }
  },

  async logAudit(action, referenceId, description, userId = 'demo-user') {
    try {
      await trickleCreateObject('audit_logs', {
        Action: action,
        ReferenceID: referenceId,
        Description: description,
        UserID: userId
      });
    } catch (error) {
      console.error('Audit log error:', error);
    }
  },

  async extractRulesFromDocument(docId, docName) {
    const fallbackRules = [
      {
        ruleText: `All data from ${docName} must be encrypted at rest and in transit`,
        category: 'Data Security',
        type: 'Control',
        confidence: 0.85,
        explanation: 'Standard data security requirement'
      },
      {
        ruleText: `Access to ${docName} requires multi-factor authentication`,
        category: 'Access Control',
        type: 'Obligation',
        confidence: 0.90,
        explanation: 'Security control to prevent unauthorized access'
      },
      {
        ruleText: `All changes to ${docName} must be logged and audited`,
        category: 'IT Governance',
        type: 'Obligation',
        confidence: 0.88,
        explanation: 'Governance requirement for tracking modifications'
      }
    ];

    for (let i = 0; i < fallbackRules.length; i++) {
      const rule = fallbackRules[i];
      await trickleCreateObject('rules', {
        RuleID: `R-${Date.now()}-${i}`,
        DocumentID: docId,
        RuleText: rule.ruleText,
        Category: rule.category,
        Type: rule.type,
        Confidence: rule.confidence,
        SourcePage: Math.floor(Math.random() * 20) + 1,
        Explanation: rule.explanation,
        Status: 'pending',
        ReviewedBy: ''
      });
    }

    await trickleUpdateObject('documents', docId, {
      Status: 'completed',
      RulesCount: fallbackRules.length
    });

    await this.logAudit('extract', docId, `Extracted ${fallbackRules.length} rules`);
    return fallbackRules.length;
  },

  async getDocumentRulesCount(docId) {
    try {
      const rules = await this.getRules(1000);
      return rules.filter(r => r.documentId === docId).length;
    } catch (error) {
      return 0;
    }
  },

  async getRulesByDocument(docId) {
    try {
      const rules = await this.getRules(1000);
      return rules.filter(r => r.documentId === docId);
    } catch (error) {
      return [];
    }
  },

  async getRule(ruleObjectId) {
    try {
      const result = await trickleGetObject('rules', ruleObjectId);
      return {
        id: result.objectId,
        ruleId: result.objectData.RuleID,
        documentId: result.objectData.DocumentID,
        ruleText: result.objectData.RuleText,
        category: result.objectData.Category,
        type: result.objectData.Type,
        confidence: result.objectData.Confidence,
        sourcePage: result.objectData.SourcePage,
        explanation: result.objectData.Explanation,
        status: result.objectData.Status,
        reviewedBy: result.objectData.ReviewedBy
      };
    } catch (error) {
      return null;
    }
  },

  generateCode(rule, language) {
    const templates = {
      Python: `# ${rule.category} - ${rule.type}\n# Rule: ${rule.ruleText}\n\ndef enforce_rule():\n    """${rule.ruleText}"""\n    try:\n        print("Enforcing: ${rule.ruleText}")\n        return True\n    except Exception as e:\n        print(f"Error: {e}")\n        return False`,
      
      Java: `// ${rule.category} - ${rule.type}\npublic class RuleEnforcer {\n    public boolean enforce() {\n        try {\n            System.out.println("Enforcing: ${rule.ruleText}");\n            return true;\n        } catch (Exception e) {\n            return false;\n        }\n    }\n}`,
      
      Drools: `rule "${rule.ruleId}"\nwhen\n    $obj : Object()\nthen\n    System.out.println("Rule: ${rule.ruleText}");\nend`
    };
    
    return templates[language] || templates['Python'];
  }
};
