class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function RepositoryApp() {
  try {
    const [commits, setCommits] = React.useState([
      {
        id: '1',
        hash: 'a1b2c3d',
        message: 'Initial policy rules implementation',
        author: 'demo-user',
        date: new Date(Date.now() - 86400000 * 2),
        filesChanged: 5
      },
      {
        id: '2',
        hash: 'e4f5g6h',
        message: 'Add data security rules',
        author: 'demo-user',
        date: new Date(Date.now() - 86400000),
        filesChanged: 3
      },
      {
        id: '3',
        hash: 'i7j8k9l',
        message: 'Update access control policies',
        author: 'demo-user',
        date: new Date(),
        filesChanged: 2
      }
    ]);

    return (
      <div className="min-h-screen">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2">Code Repository</h1>
              <p className="text-[var(--text-secondary)] text-lg">
                Version control and commit history
              </p>
            </div>
            <button className="btn btn-primary flex items-center space-x-2">
              <div className="icon-git-branch text-lg"></div>
              <span>New Branch</span>
            </button>
          </div>

          <div className="card mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
                  <div className="icon-git-commit text-xl text-purple-600"></div>
                </div>
                <div>
                  <p className="text-2xl font-bold">{commits.length}</p>
                  <p className="text-sm text-[var(--text-secondary)]">Total Commits</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-xl font-bold text-green-600">+127</p>
                  <p className="text-sm text-[var(--text-secondary)]">Additions</p>
                </div>
                <div className="text-center">
                  <p className="text-xl font-bold text-red-600">-43</p>
                  <p className="text-sm text-[var(--text-secondary)]">Deletions</p>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 className="text-xl font-bold mb-4">Commit History</h2>
            <div className="space-y-4">
              {commits.map((commit) => (
                <div key={commit.id} className="flex items-start space-x-4 pb-4 border-b border-[var(--border-color)] last:border-0">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                    <div className="icon-git-commit text-lg text-gray-600"></div>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{commit.message}</p>
                    <div className="flex items-center space-x-4 text-sm text-[var(--text-secondary)] mt-1">
                      <span className="font-mono">{commit.hash}</span>
                      <span>•</span>
                      <span>{commit.author}</span>
                      <span>•</span>
                      <span>{commit.date.toLocaleDateString()}</span>
                      <span>•</span>
                      <span>{commit.filesChanged} files changed</span>
                    </div>
                  </div>
                  <button className="text-[var(--text-secondary)] hover:text-[var(--primary-color)]">
                    <div className="icon-eye text-lg"></div>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('RepositoryApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><RepositoryApp /></ErrorBoundary>);