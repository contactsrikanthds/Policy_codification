class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Something went wrong</h1>
            <button onClick={() => window.location.reload()} className="btn btn-primary">Reload</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function AuditApp() {
  try {
    const [logs, setLogs] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    React.useEffect(() => {
      loadAuditLogs();
    }, []);

    const loadAuditLogs = async () => {
      try {
        setLoading(true);
        const auditLogs = await TrickleDB.getAuditLogs(100);
        setLogs(auditLogs);
      } catch (error) {
        console.error('Failed to load audit logs:', error);
      } finally {
        setLoading(false);
      }
    };

    const getActionIcon = (action) => {
      const icons = {
        upload: 'upload',
        extract: 'file-text',
        approve: 'check-circle',
        reject: 'x-circle',
        generate: 'code',
        commit: 'git-commit'
      };
      return icons[action] || 'activity';
    };

    const getActionColor = (action) => {
      const colors = {
        upload: 'bg-blue-100 text-blue-600',
        extract: 'bg-purple-100 text-purple-600',
        approve: 'bg-green-100 text-green-600',
        reject: 'bg-red-100 text-red-600',
        generate: 'bg-yellow-100 text-yellow-600',
        commit: 'bg-indigo-100 text-indigo-600'
      };
      return colors[action] || 'bg-gray-100 text-gray-600';
    };

    return (
      <div className="min-h-screen">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-2">Audit Trail</h1>
          <p className="text-[var(--text-secondary)] text-lg mb-8">
            Complete history of all actions and changes
          </p>

          {loading ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-full border-4 border-gray-200 border-t-[var(--primary-color)] animate-spin mx-auto mb-4"></div>
              <p className="text-[var(--text-secondary)]">Loading audit logs...</p>
            </div>
          ) : (
            <div className="card">
              <div className="space-y-4">
                {logs.map((log, index) => (
                  <div key={log.id} className="flex items-start space-x-4 pb-4 border-b border-[var(--border-color)] last:border-0">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getActionColor(log.action)}`}>
                      <div className={`icon-${getActionIcon(log.action)} text-lg`}></div>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{log.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-[var(--text-secondary)] mt-1">
                        <span>{log.userId}</span>
                        <span>•</span>
                        <span>{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    );
  } catch (error) {
    console.error('AuditApp error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><AuditApp /></ErrorBoundary>);