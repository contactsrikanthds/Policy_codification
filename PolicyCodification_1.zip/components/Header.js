function Header() {
  try {
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    
    const navItems = [
      { label: 'Dashboard', path: 'index.html', icon: 'layout-dashboard' },
      { label: 'Review', path: 'review.html', icon: 'list-checks' },
      { label: 'Generate', path: 'generate.html', icon: 'code' },
      { label: 'Search', path: 'search.html', icon: 'search' },
      { label: 'Audit', path: 'audit.html', icon: 'shield-check' },
      { label: 'Repository', path: 'repository.html', icon: 'git-branch' }
    ];

    return (
      <header className="bg-[var(--card-bg)] border-b border-[var(--border-color)] sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-[var(--primary-color)] flex items-center justify-center">
                <div className="icon-file-code text-xl text-white"></div>
              </div>
              <span className="text-xl font-bold">PolicyCode AI</span>
            </div>
            
            <nav className="hidden md:flex items-center space-x-1">
              {navItems.map(item => (
                <a
                  key={item.path}
                  href={item.path}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                    currentPath === item.path 
                      ? 'bg-[var(--primary-color)] bg-opacity-10 text-[var(--primary-color)]' 
                      : 'text-[var(--text-secondary)] hover:bg-gray-100'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span className="text-sm font-medium">{item.label}</span>
                </a>
              ))}
            </nav>

            <button className="btn btn-primary flex items-center space-x-2">
              <div className="icon-user text-lg"></div>
              <span>Sign In</span>
            </button>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}